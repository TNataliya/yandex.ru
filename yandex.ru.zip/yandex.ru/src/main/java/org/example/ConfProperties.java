package org.example;

public class ConfProperties {
}
