package ru.ya;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import java.util.Arrays;
import java.util.Set;

import static org.junit.Assert.assertEquals;
import static org.openqa.selenium.By.*;


public class FirstTest extends WebDriverSettings {


    @Test
    public void firstTest() throws InterruptedException {
        driver.get("https://ya.ru/");
        String title = driver.getTitle();
        assertEquals("Яндекс", title);
        driver.findElement(cssSelector(".services-pinned__all")).click();
        driver.get("https://market.yandex.ru/");
        driver.findElement(id("header-search")).sendKeys("Стовые телефоны\n");
        driver.findElement(linkText("Все фильтры")).click();
        driver.findElement(By.xpath("//input[@value=\"Samsung\"]")).click();
        driver.findElement(By.xpath("//input[@value=\"Xiaomi\"]")).click();
        driver.findElement(By.xpath("//input[@value=\"Apple\"]")).click();
        driver.findElement(By.xpath("//input[@value=\"realme\"]")).click();
        driver.findElement(By.xpath("//input[@value=\"BQ\"]")).click();


        }
        //driver.findElement(By.id("10706215")).click();
        //driver.findElement(By.id("16713696")).click();
        //driver.findElement(By.id("7701962")).click();



        //String text = driver.findElement(By.cssSelector("h1")).getText();//для получения среднего значения

    }